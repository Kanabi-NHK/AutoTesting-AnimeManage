package testcase;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import base.Authentication;

public class LoginPage {
    WebDriver driver;
    
    @Test
    public void testLogin() throws InterruptedException {
        // Khởi tạo Authentication
        Authentication authentication = new Authentication(driver);

        // Thực hiện đăng nhập
        authentication.login();

        // Thêm các kiểm tra hoặc hành động tiếp theo sau khi đăng nhập
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}
