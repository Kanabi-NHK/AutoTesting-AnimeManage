package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {
    private WebDriver driver;

    // Các phần tử trên trang đăng nhập
    private By usernameField = By.id("loginUserName");
    private By passwordField = By.id("login-password");
    private By loginButton = By.xpath("//input[@value='Login']");

    // Constructor nhận vào một đối tượng WebDriver
    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    // Phương thức để nhập tên đăng nhập
    public void enterUsername(String username) {
        WebElement usernameElement = driver.findElement(usernameField);
        usernameElement.clear();
        usernameElement.sendKeys(username);
    }

    // Phương thức để nhập mật khẩu
    public void enterPassword(String password) {
        WebElement passwordElement = driver.findElement(passwordField);
        passwordElement.clear();
        passwordElement.sendKeys(password);
    }

    // Phương thức để nhấn nút đăng nhập
    public void clickLoginButton() {
        WebElement loginButtonElement = driver.findElement(loginButton);
        loginButtonElement.click();
    }

    // Phương thức để đăng nhập với tên đăng nhập và mật khẩu cụ thể
    public void login(String username, String password) {
        enterUsername(username);
        enterPassword(password);
        clickLoginButton();
    }
}
