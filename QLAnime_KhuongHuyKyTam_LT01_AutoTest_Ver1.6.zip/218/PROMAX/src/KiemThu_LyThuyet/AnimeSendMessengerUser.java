package KiemThu_LyThuyet; 

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class AnimeSendMessengerUser {
    private WebDriver driver;

    @BeforeClass
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://myanimelist.net/");
        driver.manage().window().maximize();
    }

    @Test(priority = 1)
    public void testLogin() {
        WebElement loginButton = driver.findElement(By.xpath("//a[contains(text(),'Login')]"));
        loginButton.click();
        WebElement usernameField = driver.findElement(By.id("loginUserName"));
        WebElement passwordField = driver.findElement(By.id("login-password"));
        WebElement loginSubmitButton = driver.findElement(By.xpath("//input[@value='Login']"));
        usernameField.sendKeys("langxitrum"); // 
        passwordField.sendKeys("030102Ky"); // 
        loginSubmitButton.click();
        try {
            Thread.sleep(3000); 
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    @Test(priority = 2)
    public void testSearchUser() throws InterruptedException {
        
        WebElement searchButton = driver.findElement(By.xpath("//*[@id=\"header-menu\"]/div[4]/a/i"));
        searchButton.click();
        Thread.sleep(3000);
        WebElement searchButton1 = driver.findElement(By.xpath("//*[@id=\"sendmsg\"]/a"));
        searchButton1.click();
        Thread.sleep(3000);
        WebElement user = driver.findElement(By.id("toName"));
        user.sendKeys("Wikanabi53");
        Thread.sleep(3000);
        WebElement searchButton2 = driver.findElement(By.xpath("//*[@id=\"advancedSearchResultList\"]/div[1]/div/a/div/span"));
        searchButton2.click();
        try {
            Thread.sleep(3000); 
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    @Test(priority = 3)
    public void testSubmit() throws InterruptedException {
    
    	WebElement subject = driver.findElement(By.name("subject"));
        WebElement text = driver.findElement(By.xpath("//*[@id=\"dialog\"]/tbody/tr/td/form/table/tbody/tr/td/div[3]/div[1]/div/textarea"));
       
        subject.sendKeys("Add friend"); // 
        text.sendKeys("I am Kanabi"); // 
        Thread.sleep(2000);
        WebElement submit = driver.findElement(By.xpath("//*[@id=\"dialog\"]/tbody/tr/td/form/div/input[2]"));
        submit.click();
		Thread.sleep(2000);
		
       }  
    @AfterClass
    public void tearDown() {
    	try {
            Thread.sleep(3000); 
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        driver.quit();

    }
}