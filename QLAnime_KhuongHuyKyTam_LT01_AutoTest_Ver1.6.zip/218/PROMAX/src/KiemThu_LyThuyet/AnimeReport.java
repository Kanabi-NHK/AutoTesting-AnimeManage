package KiemThu_LyThuyet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class AnimeReport {
    private WebDriver driver;

    @BeforeClass
    public void setUp() {
        // Thiết lập đường dẫn đến WebDriver
        System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
        // Khởi tạo WebDriver
        driver = new ChromeDriver();
        // Mở trang web MyAnimeList
        driver.get("https://myanimelist.net/");
        driver.manage().window().maximize();
    }

    @Test(priority = 1)
    public void TestLoginAnime() {
        // Tìm kiếm nút đăng nhập và click vào nó
        WebElement loginButton = driver.findElement(By.xpath("//a[contains(text(),'Login')]"));
        loginButton.click();

        // Nhập tên người dùng và mật khẩu vào form đăng nhập
        WebElement usernameField = driver.findElement(By.id("loginUserName"));
        WebElement passwordField = driver.findElement(By.id("login-password"));
        WebElement loginSubmitButton = driver.findElement(By.xpath("//input[@value='Login']"));

        usernameField.sendKeys("langxitrum"); // 
        passwordField.sendKeys("030102Ky"); // 

        // Ấn nút đăng nhập
        loginSubmitButton.click();

        // Chờ cho trang load
        try {
            Thread.sleep(3000); // Chờ 3 giây để trang load
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Test(priority = 2)
    public void testReport() throws InterruptedException {
        
        WebElement searchButton = driver.findElement(By.xpath("//*[@id=\"nav\"]/li[7]/a"));
        searchButton.click();
        WebElement searchButton1 = driver.findElement(By.xpath("//*[@id=\"nav\"]/li[7]/ul/li[5]/a"));
        searchButton1.click();
       
        try {
            Thread.sleep(3000); // Chờ 3 giây để trang load
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    @Test(priority = 3)
    public void testSubmit() throws InterruptedException {
        // Tìm kiếm input box để nhập tên anime và nút tìm kiếm
    
    	WebElement abuse_report = driver.findElement(By.id("abuse_report"));
        abuse_report.sendKeys("Thanks"); // 

		WebElement SubmitButton = driver.findElement(By.xpath("//*[@id=\"dialog\"]/tbody/tr/td/form/div[2]/input"));
		SubmitButton.click();
       }  
    @AfterClass
    public void tearDown() {
    	try {
            Thread.sleep(3000); // Chờ 3 giây để trang load
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        driver.quit();

    }
}