package KiemThu_LyThuyet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AnimeLogin {
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();

        driver.get("https://myanimelist.net/");

        try {
            
            WebElement loginButton = driver.findElement(By.xpath("//a[contains(text(),'Login')]"));
            loginButton.click();

           
            WebElement usernameField = driver.findElement(By.id("loginUserName"));
            WebElement passwordField = driver.findElement(By.id("login-password"));
            WebElement loginSubmitButton = driver.findElement(By.xpath("//input[@value='Login']"));

            usernameField.sendKeys("langxitrum"); 
            passwordField.sendKeys("030102Ky"); 

        
            loginSubmitButton.click();

            Thread.sleep(3000);

            WebElement searchBox = driver.findElement(By.xpath("//input[@id='topSearchText']"));
            WebElement searchButton = driver.findElement(By.xpath("//button[@type='submit' and @class='icon-search']"));

            searchBox.sendKeys("Naruto");

            searchButton.click();

            Thread.sleep(5000); 

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            driver.quit();
        }
    }
}
