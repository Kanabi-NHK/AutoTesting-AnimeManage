package KiemThu_LyThuyet;

import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;

public class Login_Register {
    WebDriver driver;
    String[][] data = null;

    @Test(dataProvider = "dpLogin")
    public void testLogin(String email, String password, String loginMethod) throws InterruptedException {
        driver.get("https://myanimelist.net/login.php");


        switch (loginMethod) {
            case "Google":
                loginWithGoogle(email, password);
                break;
            case "Facebook":
                loginWithFacebook(email, password);
                break;
            case "Twitter":
                loginWithTwitter(email, password);
                break;
            default:
                System.out.println("Phương thức đăng nhập không được hỗ trợ: " + loginMethod);
        }
    }


    public void loginWithGoogle(String email, String password) throws InterruptedException {

        driver.findElement(By.id("google-button")).click();
        Thread.sleep(2000);
        driver.findElement(By.id("identifierId")).sendKeys(email + Keys.ENTER);
        Thread.sleep(2000);
        driver.findElement(By.name("password")).sendKeys(password + Keys.ENTER);
    }

    public void loginWithFacebook(String email, String password) throws InterruptedException {
        driver.findElement(By.id("facebook-login-button")).click();
        Thread.sleep(2000);
        driver.findElement(By.id("email")).sendKeys(email);
        driver.findElement(By.id("pass")).sendKeys(password);
        driver.findElement(By.id("loginbutton")).click();
    }


    public void loginWithTwitter(String email, String password) throws InterruptedException {
        driver.findElement(By.id("twitter-login-button")).click();
        Thread.sleep(2000);
        driver.findElement(By.id("username")).sendKeys(email);
        driver.findElement(By.id("password")).sendKeys(password);
        driver.findElement(By.id("loginbutton")).click();
    }

    @BeforeMethod
    public void beforeMethod() {
        System.out.println("Bắt đầu kiểm tra");
        System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    @AfterMethod
    public void afterMethod() {
        driver.quit();
    }

    @DataProvider(name = "dpLogin")
    public String[][] readLoginData() throws IOException, ParseException {
        return readData("D:\\testdata.json", "userlogins");
    }

    @DataProvider(name = "dpRegister")
    public String[][] readRegisterData() throws IOException, ParseException {
        return readData("D:\\testdata.json", "userregistrations");
    }

    public String[][] readData(String filePath, String dataKey) throws IOException, ParseException {
        String email = null;
        String username = null;
        String pass = null;
        String birthday = null;
        String loginMethod = null; 
        FileReader reader = new FileReader(filePath);
        JSONParser jsonParser = new JSONParser();
        Object jsonObject = jsonParser.parse(reader);

        JSONObject jsonObj = (JSONObject) jsonObject;

        JSONArray array = (JSONArray) jsonObj.get(dataKey);
        String arr[][] = new String[array.size()][5]; 
        for (int i = 0; i < array.size(); i++) {
            JSONObject userData = (JSONObject) array.get(i);

            email = (String) userData.get("email");
            username = (String) userData.get("username");
            pass = (String) userData.get("password");
            birthday = (String) userData.get("birthday");
            loginMethod = (String) userData.get("loginMethod"); 

            arr[i][0] = email;
            arr[i][1] = username;
            arr[i][2] = pass;
            arr[i][3] = birthday;
            arr[i][4] = loginMethod; 
        }
        return arr;
    }
}
