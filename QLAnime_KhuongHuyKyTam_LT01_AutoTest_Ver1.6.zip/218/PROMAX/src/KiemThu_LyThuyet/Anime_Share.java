package KiemThu_LyThuyet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Anime_Share {
    private WebDriver driver;

    @BeforeClass
    public void setUp() {
        // Thiết lập đường dẫn đến WebDriver
        System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
        // Khởi tạo WebDriver
        driver = new ChromeDriver();
        // Mở trang web MyAnimeList
        driver.get("https://myanimelist.net/");
    }

    @Test(priority = 1)
    public void testLogin() {
        // Tìm kiếm nút đăng nhập và click vào nó
        WebElement loginButton = driver.findElement(By.xpath("//a[contains(text(),'Login')]"));
        loginButton.click();

        // Nhập tên người dùng và mật khẩu vào form đăng nhập
        WebElement usernameField = driver.findElement(By.id("loginUserName"));
        WebElement passwordField = driver.findElement(By.id("login-password"));
        WebElement loginSubmitButton = driver.findElement(By.xpath("//input[@value='Login']"));

        usernameField.sendKeys("langxitrum"); // Thay your_username bằng tên người dùng của bạn
        passwordField.sendKeys("030102Ky"); // Thay your_password bằng mật khẩu của bạn

        // Ấn nút đăng nhập
        loginSubmitButton.click();

        // Chờ cho trang load
        try {
            Thread.sleep(3000); // Chờ 3 giây để trang load
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Test(priority = 2, dependsOnMethods = {"testLogin"})
    public void testSearch() throws InterruptedException {
        // Tìm kiếm input box để nhập tên anime và nút tìm kiếm
    	WebElement loginseach = driver.findElement(By.name("topkeyword"));
    	loginseach.click();
        WebElement searchtext = driver.findElement(By.id("topSearchText"));
        searchtext.sendKeys("Kimetsu no Yaiba: Hashira Geiko-hen"); // Thay your_username bằng tên người dùng của bạn
      
        WebElement searchButton = driver.findElement(By.xpath("//*[@id=\"topSearchButon\"]/i"));

        // Click vào nút tìm kiếm
        searchButton.click();
        try {
            Thread.sleep(3000); // Chờ 3 giây để trang load
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
     // Kiểm tra kết quả tìm kiếm
        WebElement result = driver.findElement(By.className("js-categories-seasonal"));
        Assert.assertTrue(result.getText().toLowerCase().contains("Kimetsu no Yaiba: Hashira Geiko-hen"), "Search failed!");
    }
    @Test(priority = 3)
    public void click() throws InterruptedException {
        // Tìm kiếm input box để nhập tên anime và nút tìm kiếm
    
    	WebElement select = driver.findElement(By.xpath("//*[@id=\"#revAreaAnimeHover55701\"]"));
        select.click();
        Thread.sleep(2000);
      
        WebElement share = driver.findElement(By.xpath("//*[@id=\"content\"]/table/tbody/tr/td[1]/div/div[7]/a[1]/div/i"));
        share.click();
        Thread.sleep(2000);
        // Click vào nút tìm kiếm
       }  
    @AfterClass
    public void tearDown() {
    	try {
            Thread.sleep(3000); // Chờ 3 giây để trang load
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        driver.quit();

    }
}