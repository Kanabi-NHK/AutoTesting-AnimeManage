package KiemThu_LyThuyet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

public class upanhdaidien {
    public static void main(String[] args) throws InterruptedException, AWTException {
      
        System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");

   
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        // Mở trang web MyAnimeList
        driver.get("https://myanimelist.net/");

        try {
            
            WebElement loginButton = driver.findElement(By.xpath("//a[contains(text(),'Login')]"));
            loginButton.click();

          
            WebElement usernameField = driver.findElement(By.id("loginUserName"));
            WebElement passwordField = driver.findElement(By.id("login-password"));
            WebElement loginSubmitButton = driver.findElement(By.xpath("//input[@value='Login']"));

            usernameField.sendKeys("langxitrum"); 
            passwordField.sendKeys("030102Ky"); 

     
            loginSubmitButton.click();

            Thread.sleep(3000);

          
            driver.get("https://myanimelist.net/editprofile.php?go=picture");
            Thread.sleep(3000);

  
            driver.findElement(By.name("file")).click();
    		driver.switchTo().activeElement();

            Thread.sleep(2000);

          
            StringSelection ss = new StringSelection("C:\\Users\\PC\\eclipse-workspace\\KTATUOU4\\src\\TH6\\anh.jpg");
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
            Robot robot = new Robot();
            robot.delay(1000);

          
            robot.keyPress(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_V);
            robot.keyRelease(KeyEvent.VK_V);
            robot.keyRelease(KeyEvent.VK_CONTROL);
            robot.delay(1000);

          
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);

            Thread.sleep(3000); 
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        
            driver.quit();
        }
    }
}