package KiemThu_LyThuyet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Kiemtratukhoa {

    private WebDriver driver;

    @BeforeTest
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "c:\\chromedriver.exe");
        driver = new ChromeDriver();
    }

    @Test
    public void testGetMetaDescription() {
        driver.get("https://myanimelist.net/anime/1735/Naruto__Shippuuden");

        // Lấy nội dung 
        WebElement metaDescriptionElement = driver.findElement(By.cssSelector("meta[name='description']"));
        String metaDescriptionContent = metaDescriptionElement.getAttribute("content");

        // Kiểm tra 
        Assert.assertTrue(metaDescriptionContent.contains("Looking for information on the anime Naruto: Shippuuden (Naruto Shippuden)?"));

        //  in ra màn hình
        Reporter.log("Meta Description: " + metaDescriptionContent);
    }

    @AfterTest
    public void tearDown() {
        driver.quit();
    }
}

