package KiemThu_LyThuyet;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class KiemtraNoiDung {

    WebDriver driver;

    @BeforeTest
    public void setUp() throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "c:\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://myanimelist.net/");
        Thread.sleep(2000);
    }

    @Test
    public void testNavigation() throws InterruptedException {
        driver.navigate().to("https://myanimelist.net/anime/1735/Naruto__Shippuuden");
        Thread.sleep(2000);
        String dinhdanh = driver.getWindowHandle();
        System.out.println(dinhdanh);
        System.out.println(driver.getCurrentUrl());

        driver.navigate().back();
        Thread.sleep(2000);

        driver.navigate().forward();
        Thread.sleep(2000);

        driver.navigate().refresh();
        Thread.sleep(1000);

        System.out.println(driver.getTitle());
    }

    @AfterTest
    public void tearDown() {
        driver.quit();
    }
}
