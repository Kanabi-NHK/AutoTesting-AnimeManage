package KiemThu_LyThuyet;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class kiemtraTile {

    public static void main(String[] args) throws InterruptedException {
        // TODO Auto-generated method stub
        System.setProperty("webdriver.chrome.driver", "c:\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.navigate().to("https://myanimelist.net/");
        Thread.sleep(3000);

        String KetquaMongDoi = "MyAnimeList.net - Anime and Manga Database and Community";
        String KetquaThucTe = driver.getTitle();

        if (KetquaThucTe.contentEquals(KetquaMongDoi)) {
            System.out.println("PASS");
            System.out.println("Kết quả mong đợi là: " + KetquaMongDoi);
            System.out.println("Kết quả thực tế là: " + KetquaThucTe);
            
        } else {
            System.out.println("FAIL");
            System.out.println("Kết quả mong đợi là: " + KetquaMongDoi);
            System.out.println("Kết quả thực tế là: " + KetquaThucTe);
            
        }

    driver.close();

    }
}
