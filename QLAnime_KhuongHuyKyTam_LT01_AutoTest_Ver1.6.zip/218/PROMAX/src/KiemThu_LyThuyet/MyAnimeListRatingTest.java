package KiemThu_LyThuyet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class MyAnimeListRatingTest {

    private WebDriver driver;

    @BeforeClass
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
        driver = new ChromeDriver();
    }

    @Test
    public void login() {
        driver.get("https://myanimelist.net/");

        try {
            WebElement loginButton = driver.findElement(By.xpath("//a[contains(text(),'Login')]"));
            loginButton.click();

            WebElement usernameField = driver.findElement(By.id("loginUserName"));
            WebElement passwordField = driver.findElement(By.id("login-password"));
            WebElement loginSubmitButton = driver.findElement(By.xpath("//input[@value='Login']"));

            usernameField.sendKeys("langxitrum");
            passwordField.sendKeys("030102Ky");

            loginSubmitButton.click();

            WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.urlContains("myanimelist.net")); // Wait for login success

            Thread.sleep(3000); // Wait for page to load after login

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test(dependsOnMethods = "login")
    public void rateAnime() {
        String animeUrl = "https://myanimelist.net/anime/5114/Fullmetal_Alchemist__Brotherhood"; // Example URL
        int rating = 10; // Rating value (1-10)

        driver.get(animeUrl);

        WebDriverWait wait = new WebDriverWait(driver, 9);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("myinfo_score")));

        WebElement ratingDropdown = driver.findElement(By.id("myinfo_score"));
        Select select = new Select(ratingDropdown);

        select.selectByValue(String.valueOf(rating));
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}
