package KiemThu_LyThuyet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

public class Review {
    private WebDriver driver;

    @BeforeMethod
    public void setup() {
        System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");

        // Khởi tạo WebDriver
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }

    @Test(dataProvider = "animeData")
    public void addAnimeToList(String status, String score, String epsSeen) {
        driver.get("https://myanimelist.net/addtolist.php");

        WebElement statusDropdownLink = driver.findElement(By.xpath("//*[@id=\"btnStatusAnimeAdd29831\"]/a"));
        statusDropdownLink.click();

        // Chọn trạng thái
        Select statusDropdown = new Select(driver.findElement(By.name("status")));
        statusDropdown.selectByVisibleText(status);

        // Chọn điểm số
        Select scoreDropdown = new Select(driver.findElement(By.name("score")));
        scoreDropdown.selectByVisibleText(score);

        // Nhập số tập đã xem
        WebElement epsSeenInput = driver.findElement(By.name("eps_seen"));
        epsSeenInput.sendKeys(epsSeen);

        // Nhấp vào nút "Today" cho ngày bắt đầu và kết thúc
        WebElement startDateTodayButton = driver.findElement(By.xpath("//*[@id=\"content\"]/form/table/tbody/tr[6]/td[3]/input[1]"));
        startDateTodayButton.click();

        WebElement endDateTodayButton = driver.findElement(By.xpath("//*[@id=\"content\"]/form/table/tbody/tr[7]/td[3]/input[1]"));
        endDateTodayButton.click();
    }

    @AfterMethod
    public void tearDown() {
        driver.quit();
    }

    @DataProvider(name = "animeData")
    public Object[][] provideAnimeData() {
        return new Object[][] {
                {"Watching", "9", "1"},
                {"Completed", "10", "12"},
                {"Plan to watch", "8", "0"}

        };
    }
}
