package KiemThu_LyThuyet;

import org.openqa.selenium.By; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


public class AnimeSearchTest {
    public String baseUrl = "https://myanimelist.net/";
    String driverPath = "C:\\chromedriver.exe";
    public WebDriver driver;

    @BeforeTest
    public void launchBrowser() {
        System.out.println("Chạy trình duyệt chrome");
        System.setProperty("webdriver.chrome.driver", driverPath);
        driver = new ChromeDriver();
        driver.get(baseUrl);
        driver.manage().window().maximize();
    }

    @Test(priority = 1)
    public void testLogin() {
        WebElement loginButton = driver.findElement(By.xpath("//a[contains(text(),'Login')]"));
        loginButton.click();

        WebElement usernameField = driver.findElement(By.id("loginUserName"));
        WebElement passwordField = driver.findElement(By.id("login-password"));
        WebElement loginSubmitButton = driver.findElement(By.xpath("//input[@value='Login']"));

        usernameField.sendKeys("langxitrum");
        passwordField.sendKeys("030102Ky");

        loginSubmitButton.click();

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Test(priority = 2, dependsOnMethods = {"testLogin"})
    public void testSearch() {
        WebElement searchBox = driver.findElement(By.name("topkeyword"));
        searchBox.click();
        WebElement searchText = driver.findElement(By.id("topSearchText"));
        searchText.sendKeys("Naruto: Shippuuden Movie 2 - Kizuna");

        WebElement searchButton = driver.findElement(By.xpath("//*[@id=\"topSearchButon\"]/i"));
        searchButton.click();

        // Chờ cho trang load
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        WebElement searchResult = driver.findElement(By.xpath("//a[contains(text(),'Naruto: Shippuuden Movie 2 - Kizuna')]"));
        searchResult.click();

        // Chờ cho trang chi tiết load
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        String pageTitle = driver.getTitle();

        // So sánh tiêu đề của trang với tiêu đề mong đợi
        String expectedTitle = "Naruto: Shippuuden Movie 2 - Kizuna - MyAnimeList.net";
        Assert.assertEquals(pageTitle, expectedTitle, "Page title is not as expected.");
    }

    @AfterTest
    public void terminateBrowser() {
        driver.quit();
    }
}
