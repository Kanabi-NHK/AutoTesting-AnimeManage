package base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import page.LoginPage;

public class Authentication {
    WebDriver driver;

    public Authentication(WebDriver driver) {
        this.driver = driver;
    }

    public void login() throws InterruptedException {
        // Khởi tạo trình duyệt Chrome
        System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();

        // Khởi tạo LoginPage
        LoginPage loginPage = new LoginPage(driver);

        // Mở trang đăng nhập của MyAnimeList
        driver.get("https://myanimelist.net/login.php");

        // Đăng nhập với thông tin tài khoản cụ thể
        loginPage.login("langxitrum", "030102Ky");
    }
}
